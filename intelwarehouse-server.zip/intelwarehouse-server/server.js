// call the packages we need
var express = require('express');        // call express
var app = express();                 // define our app using express
var bodyParser = require('body-parser');
var mysql = require('mysql');
var cors = require('cors')
var cron = require('node-cron');

var con = mysql.createConnection({
	host: 'localhost',
	user: 'root',
	//password: 'password',
	password: '',
	database: 'intelwarehouse'
});

con.connect((err) => {
	if (err) throw err;
	console.log('Connected!');
});

// configure app to use bodyParser()
// this will let us get the data from a POST
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

//var port = process.env.PORT || 8080;        // set our port
var port = process.env.PORT || 3000;        // set our port

// ROUTES FOR OUR API
// =============================================================================
var router = express.Router();              // get an instance of the express Router

// middleware for all routes
router.use(function (req, res, next) {
	// inject default headers
	var allowedOrigins = ['http://localhost:4200', 'http://52.8.222.39', 'http://foodservice.zensense.io'];
	var origin = req.headers.origin;
	if (allowedOrigins.indexOf(origin) > -1) {
		res.setHeader('Access-Control-Allow-Origin', origin);
	}
	//res.header('Access-Control-Allow-Origin', 'http://52.8.222.39');
	//res.header('Access-Control-Allow-Origin', 'http://localhost:4200');
	res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
	res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
	next();
});


// test route to make sure everything is working (accessed at GET http://localhost:8080/api)
router.get('/', function (req, res) {
	res.json({ message: 'hooray! welcome to our api!' });
});

// more routes for our API will happen here

router.route('/test')

	// create a bear (accessed at POST http://localhost:8080/api/test)
	.post(function (req, res) {

		var name = req.body.name;  // set the bears name (comes from the request)
		con.query("SELECT * FROM USERS", function (err, result, fields) {
			if (err) throw err;
			//console.log(result);		
			res.json({ message: result });
		});

	});

router.route('/getUserToken')

	// create a bear (accessed at POST http://localhost:8080/api/getUserToken)
	.post(function (req, res) {

		var wherestring = "";

		if (req.body.username !== "") {
			wherestring = " where u.email = '" + req.body.username + "'";
		}
		if (req.body.password !== "") {
			wherestring = wherestring + " and u.password = '" + req.body.password + "'";
		}
		if (req.body.role !== "") {
			wherestring = wherestring + " and u.roleid = '" + req.body.role + "'";
		}

		var sql = "select * from users u"
		sql = sql + " inner join userrole ur on ur.id = u.roleid ";
		sql = sql + wherestring;
		sql = sql + " order by u.id";
		//console.log(sql);
		con.query(sql, function (err, result, fields) {
			if (err) throw err;
			//console.log(result);		
			res.json({ Result: result });
		});

	});

router.route('/getGatewayIds')

	// create a bear (accessed at POST http://localhost:8080/api/test)
	.get(function (req, res) {

		con.query("SELECT * FROM Gateways", function (err, result, fields) {
			if (err) throw err;
			res.json({ Result: result });
		});

	});

router.route('/getTagsIds')

	// create a bear (accessed at POST http://localhost:8080/api/test)
	.get(function (req, res) {

		con.query("SELECT * FROM tags", function (err, result, fields) {
			if (err) throw err;
			res.json({ Result: result });
		});

	});

router.route('/GetStationarytype')

	// create a bear (accessed at POST http://localhost:8080/api/GetStationarytype)
	.get(function (req, res) {

		var sql = "select * from Stationarytype";
		con.query(sql, function (err, result, fields) {
			if (err) throw err;
			//console.log(result);		
			res.json({ Result: result });
		});

	});

router.route('/saveStationary')

	// create a bear (accessed at POST http://localhost:8080/api/saveStationary)
	.post(function (req, res) {
		let dateTime = formatDateTime(new Date());
		//console.log(dateTime);
		var sql = ""; 

		if (req.body.id === 0) {
			sql = "insert into stationary (userid, s_typeid, stationaryname, datecreated) values ( ";
			sql = sql + req.body.userid + "," + req.body.s_typeid + ",'" + req.body.stationaryname + "','" + dateTime + "')";
		}else{
			sql = "update stationary set stationaryname='" + req.body.stationaryname + "' where id=" + req.body.id + ";";
		}

		con.query(sql, function (err, result, fields) {
			if (err) throw err;
			//console.log(result);		
			res.json({ Result: result });
		});
		//res.json({ Result: dateTime });
	});

router.route('/GetStationaryList')

	// create a bear (accessed at POST http://localhost:8080/api/GetStationaryList)
	.post(function (req, res) {

		var wherestring = "";

		if (req.body.id > 0) {
			wherestring = " where s.id = " + req.body.id + "";
		}
		if (req.body.mode === "AG") {
			wherestring = " where s.gatewayid = 0 ";
		}
		if (req.body.mode === "AT") {
			wherestring = " where s.tagid = 0 ";
		}
		var sql = "select *, s.id as sid, s.datecreated as sdatecreated from Stationary s"
		sql = sql + " inner join stationarytype st on st.id = s.s_typeid ";
		sql = sql + wherestring;
		sql = sql + " order by s.id";
		//console.log(sql);
		con.query(sql, function (err, result, fields) {
			if (err) throw err;
			//console.log(result);		
			res.json({ Result: result });
		});

	});

router.route('/GetMovingtype')

	// create a bear (accessed at POST http://localhost:8080/api/GetMovingtype)
	.get(function (req, res) {

		var sql = "select * from movingtype";
		con.query(sql, function (err, result, fields) {
			if (err) throw err;
			//console.log(result);		
			res.json({ Result: result });
		});

	});

router.route('/GetMovingList')

	// create a bear (accessed at POST http://localhost:8080/api/GetMovingList)
	.post(function (req, res) {

		var wherestring = "";

		if (req.body.id > 0) {
			wherestring = " where m.id = " + req.body.id + "";
		}
		if (req.body.mode === "AG") {
			wherestring = " where m.gatewayid = 0 ";
		}
		if (req.body.mode === "AT") {
			wherestring = " where m.tagid = 0 ";
		}
		var sql = "select *, m.id as mid, m.datecreated as mdatecreated from moving m"
		sql = sql + " inner join movingtype mt on mt.id = m.m_typeid ";
		sql = sql + wherestring;
		sql = sql + " order by m.id";
		con.query(sql, function (err, result, fields) {
			if (err) throw err;
			//console.log(result);		
			res.json({ Result: result });
		});

	});

router.route('/saveMoving')

	// create a bear (accessed at POST http://localhost:8080/api/saveMoving)
	.post(function (req, res) {
		let dateTime = formatDateTime(new Date());
		//console.log(dateTime);
		var sql = ""; 

		if (req.body.id === 0) {
			sql = "insert into moving (userid, m_typeid, movingname, datecreated) values ( ";
			sql = sql + req.body.userid + "," + req.body.m_typeid + ",'" + req.body.movingname + "','" + dateTime + "')";
		}else{
			sql = "update moving set movingname='" + req.body.movingname + "' where id=" + req.body.id + ";";
		}

		con.query(sql, function (err, result, fields) {
			if (err) throw err;
			//console.log(result);		
			res.json({ Result: result });
		});
		//res.json({ Result: dateTime });
	});

router.route('/DeleteMoving')

	// create a bear (accessed at POST http://localhost:8080/api/DeleteMoving)
	.post(function (req, res) {

		var wherestring = "";

		if (req.body.id > 0) {
			wherestring = " where id = " + req.body.id + "";
		}
		var sql = "delete from moving "
		sql = sql + wherestring;
		con.query(sql, function (err, result, fields) {
			if (err) throw err;
			//console.log(result);		
			res.json({ Result: result });
		});

	});

router.route('/DeleteStationary')

	// create a bear (accessed at POST http://localhost:8080/api/DeleteStationary)
	.post(function (req, res) {

		var wherestring = "";

		if (req.body.id > 0) {
			wherestring = " where id = " + req.body.id + "";
		}
		var sql = "delete from stationary "
		sql = sql + wherestring;
		con.query(sql, function (err, result, fields) {
			if (err) throw err;
			//console.log(result);		
			res.json({ Result: result });
		});

	});

router.route('/GetgatewayList')

	// create a bear (accessed at POST http://localhost:8080/api/GetMovingList)
	.post(function (req, res) {

		var wherestring = "";

		if (req.body.id > 0) {
			wherestring = " where ag.id = " + req.body.id + "";
		}
		var sql = "select *, ag.id as agid, ag.datecreated as agdatecreated ";
		sql = sql + " , case when s.gatewayid <> '' then 'Stationary' when m.gatewayid <> '' then 'Moving' else 'Not Associated' end as associatedin ";
		sql = sql + " , case when s.gatewayid <> '' then s.stationaryname when m.gatewayid <> '' then m.movingname else 'Not Associated' end as assetname ";
		sql = sql + " , case when s.gatewayid <> '' then s.stationaryname when m.gatewayid <> '' then m.movingname else ag.gatewayUUID end as chartAssetName ";
		sql = sql + " from gateways ag ";
		sql = sql + " left join stationary s on s.gatewayid = ag.id ";
		sql = sql + " left join moving m on m.gatewayid = ag.id ";
		sql = sql + wherestring;
		sql = sql + " order by ag.id";
		con.query(sql, function (err, result, fields) {
			if (err) throw err;
			//console.log(result);		
			res.json({ Result: result });
		});

	});

router.route('/AssociateGateway')

	// create a bear (accessed at POST http://localhost:8080/api/DeleteStationary)
	.post(function (req, res) {

		var sql = "";
		console.log(req.body.mode + "node" + req.body.associateId);
		if (req.body.mode === "S") {
			sql = "update stationary set gatewayid=" + req.body.id + " where id=" + req.body.associateId + ";";
		}
		if (req.body.mode === "M") {
			sql = "update moving set gatewayid=" + req.body.id + " where id=" + req.body.associateId + ";";
		}

		con.query(sql, function (err, result, fields) {
			if (err) throw err;
			//console.log(result);		
			res.json({ Result: result });
		});
		res.json({ Result: "result" });
	});

router.route('/DissociateGateway')

	// create a bear (accessed at POST http://localhost:8080/api/DissociateGateway)
	.post(function (req, res) {

		var sql = "";

		if (req.body.mode === "S") {
			sql = "update stationary set gatewayid=0 where gatewayid=" + req.body.id + ";";
		}
		if (req.body.mode === "M") {
			sql = "update moving set gatewayid=0 where gatewayid=" + req.body.id + ";";
		}

		con.query(sql, function (err, result, fields) {
			if (err) throw err;
			//console.log(result);		
			res.json({ Result: result });
		});
		res.json({ Result: "result" });
	});

router.route('/GetTagsList')

	// create a bear (accessed at POST http://localhost:8080/api/GetTagsList)
	.post(function (req, res) {

		var wherestring = "";

		if (req.body.id > 0) {
			wherestring = " where at.id = " + req.body.id + "";
		}
		var sql = "select *, at.id as atid, at.datecreated as atdatecreated ";
		sql = sql + " , case when s.tagid <> '' then 'Stationary' when m.tagid <> '' then 'Moving' else 'Not Associated' end as associatedin ";
		sql = sql + " , case when s.tagid <> '' then s.stationaryname when m.tagid <> '' then m.movingname else 'Not Associated' end as assetname ";
		sql = sql + " from tags at ";
		sql = sql + " left join stationary s on s.tagid = at.id ";
		sql = sql + " left join moving m on m.tagid = at.id ";
		sql = sql + wherestring;
		sql = sql + " order by at.id";
		con.query(sql, function (err, result, fields) {
			if (err) throw err;
			//console.log(result);		
			res.json({ Result: result });
		});

	});

router.route('/AssociateTag')

	// create a bear (accessed at POST http://localhost:8080/api/AssociateTag)
	.post(function (req, res) {

		var sql = "";
		console.log(req.body.mode + "node" + req.body.associateId);
		if (req.body.mode === "S") {
			sql = "update stationary set tagid=" + req.body.id + " where id=" + req.body.associateId + ";";
		}
		if (req.body.mode === "M") {
			sql = "update moving set tagid=" + req.body.id + " where id=" + req.body.associateId + ";";
		}

		con.query(sql, function (err, result, fields) {
			if (err) throw err;
			//console.log(result);		
			res.json({ Result: result });
		});
		res.json({ Result: "result" });
	});

router.route('/DissociateTag')

	// create a bear (accessed at POST http://localhost:8080/api/DissociateTag)
	.post(function (req, res) {

		var sql = "";

		if (req.body.mode === "S") {
			sql = "update stationary set tagid=0 where tagid=" + req.body.id + ";";
		}
		if (req.body.mode === "M") {
			sql = "update moving set tagid=0 where tagid=" + req.body.id + ";";
		}

		con.query(sql, function (err, result, fields) {
			if (err) throw err;
			//console.log(result);		
			res.json({ Result: result });
		});
		res.json({ Result: "result" });
	});

router.route('/GetGatewaySensorList')

	// create a bear (accessed at POST http://localhost:8080/api/GetGatewaySensorList)
	.post(function (req, res) {

		var wherestring = "";
		var orderbystring = "";

		if (req.body.gatewayid !== "0") {
			wherestring = " where gw.gatewayUUID = '" + req.body.gatewayid + "'";
		}
		if (req.body.daterange !== "0" && req.body.gatewayid !== "0") {
			//orderbystring = " , DATE(gatewayReceivedTime) asc";			
			if (req.body.daterange == "1") {
				let gatewayReceivedTime = formatDate(new Date());
				wherestring = wherestring + " and DATE(gatewayReceivedTime) = '" + gatewayReceivedTime + "'";
			}
			if (req.body.daterange == "2") {
				wherestring = wherestring + " and gatewayReceivedTime between date_sub(now(),INTERVAL 1 WEEK) and now()";
			}
			if (req.body.daterange == "3") {
				wherestring = wherestring + " and gatewayReceivedTime between date_sub(now(),INTERVAL 2 WEEK) and now()";
			}
			if (req.body.daterange == "4") {
				wherestring = wherestring + " and gatewayReceivedTime < Now() and gatewayReceivedTime > DATE_ADD(Now(), INTERVAL- 1 MONTH)";
			}
			if (req.body.daterange == "5") {
				wherestring = wherestring + " and gatewayReceivedTime < Now() and gatewayReceivedTime > DATE_ADD(Now(), INTERVAL- 6 MONTH)";
			}
			if (req.body.daterange == "6") {
				wherestring = wherestring + " and gatewayReceivedTime < Now() and gatewayReceivedTime > DATE_ADD(Now(), INTERVAL- 12 MONTH)";
			}
		} else {
			if (req.body.daterange !== "0") {
				//orderbystring = " , DATE(gatewayReceivedTime) asc";
				if (req.body.daterange == "1") {
					let gatewayReceivedTime = formatDate(new Date());
					wherestring = " where DATE(gatewayReceivedTime) = '" + gatewayReceivedTime + "'";
				}
				if (req.body.daterange == "2") {
					wherestring = " where gatewayReceivedTime between date_sub(now(),INTERVAL 1 WEEK) and now()";
				}
				if (req.body.daterange == "3") {
					wherestring = " where gatewayReceivedTime between date_sub(now(),INTERVAL 2 WEEK) and now()";
				}
				if (req.body.daterange == "4") {
					wherestring = wherestring + " where gatewayReceivedTime < Now() and gatewayReceivedTime > DATE_ADD(Now(), INTERVAL- 1 MONTH)";
				}
				if (req.body.daterange == "5") {
					wherestring = wherestring + " where gatewayReceivedTime < Now() and gatewayReceivedTime > DATE_ADD(Now(), INTERVAL- 6 MONTH)";
				}
				if (req.body.daterange == "6") {
					wherestring = wherestring + " where gatewayReceivedTime < Now() and gatewayReceivedTime > DATE_ADD(Now(), INTERVAL- 12 MONTH)";
				}
			}else{
				if (req.body.sdate !== "0" && req.body.gatewayid !== "0") {

					let sdate = formatDate(new Date(req.body.sdate));
					wherestring = wherestring + " and DATE(gatewayReceivedTime) = '" + sdate + "'";

				}else{
					if (req.body.sdate !== "0") {

							let sdate = formatDate(new Date(req.body.sdate));
							wherestring = " where DATE(gatewayReceivedTime) = '" + sdate + "'";

					}
				}
			}
		}
		
		orderbystring = " STR_TO_DATE(gatewayReceivedTime, '%Y-%m-%d %H:%i:%s') "+ req.body.orderby;

		var sql = "select *, STR_TO_DATE(sd.gatewayReceivedTime, '%Y-%m-%d %H:%i:%s') as gatewayReceivedTime, STR_TO_DATE(sd.tagCapturedTime, '%Y-%m-%d %H:%i:%s') as tagCapturedTime, ROUND(sd.temperatureValue * 9.0 / 5.0 + 32, 2) as temperatureValue ";
		sql = sql + ", case when (select 1 from stationary s inner join gateways g on g.id = s.gatewayid where g.gatewayUUID=sd.gatewayId) = 1 ";
		sql = sql + " then (select stationaryname from stationary s inner join gateways g on g.id = s.gatewayid where g.gatewayUUID=sd.gatewayId)  WHEN (select 1 from moving m inner join gateways g on g.id = m.gatewayid where g.gatewayUUID=sd.gatewayId) = 1 then (select movingname from moving m inner join gateways g on g.id = m.gatewayid where g.gatewayUUID=sd.gatewayId)  else sd.gatewayId end as gatewayname ";
		sql = sql + ", case when (select 1 from stationary s inner join tags t on t.id = s.tagid where t.tagUUID=sd.tagId) = 1 ";
		sql = sql + " then (select stationaryname from stationary s inner join tags t on t.id = s.tagid where t.tagUUID=sd.tagId)  WHEN (select 1 from moving m inner join tags t on t.id = m.tagid where t.tagUUID=sd.tagId) = 1 then (select movingname from moving m inner join tags t on t.id = m.tagid where t.tagUUID=sd.tagId)  else sd.tagId end as tagname ";
		sql = sql + " from sensordata sd ";
		sql = sql + " inner join gateways gw on gw.gatewayUUID = sd.gatewayid ";
		//sql = sql + " inner join tags t on t.tagUUID = sd.tagid ";
		sql = sql + wherestring;
		sql = sql + " order by " + orderbystring;
		//console.log(sql);
		con.query(sql, function (err, result, fields) {
			if (err) throw err;
			//console.log(result);		
			res.json({ Result: result });
		});

	});

router.route('/GetTagSensorList')

	// create a bear (accessed at POST http://localhost:8080/api/GetTagSensorList)
	.post(function (req, res) {

		var wherestring = "";
		var orderbystring = "";		

		if (req.body.tagid !== "0") {
			console.log(req.body.tagid);
			wherestring = " where t.tagUUID = '" + req.body.tagid + "'";
		}

		if (req.body.daterange !== "0" && req.body.tagid !== "0") {
			//orderbystring = " , DATE(tagCapturedTime) asc";			
			if (req.body.daterange == "1") {
				let tagCapturedTime = formatDate(new Date());
				wherestring = wherestring + " and DATE(tagCapturedTime) = '" + tagCapturedTime + "'";
			}
			if (req.body.daterange == "2") {
				wherestring = wherestring + " and tagCapturedTime between date_sub(now(),INTERVAL 1 WEEK) and now()";
			}
			if (req.body.daterange == "3") {
				wherestring = wherestring + " and tagCapturedTime between date_sub(now(),INTERVAL 2 WEEK) and now()";
			}
			if (req.body.daterange == "4") {
				wherestring = wherestring + " and tagCapturedTime < Now() and tagCapturedTime > DATE_ADD(Now(), INTERVAL- 1 MONTH)";
			}
			if (req.body.daterange == "5") {
				wherestring = wherestring + " and tagCapturedTime < Now() and tagCapturedTime > DATE_ADD(Now(), INTERVAL- 6 MONTH)";
			}
			if (req.body.daterange == "6") {
				wherestring = wherestring + " and tagCapturedTime < Now() and tagCapturedTime > DATE_ADD(Now(), INTERVAL- 12 MONTH)";
			}
		} else {
			if (req.body.daterange !== "0") {
				//orderbystring = " , DATE(tagCapturedTime) asc";
				if (req.body.daterange == "1") {
					let tagCapturedTime = formatDate(new Date());
					wherestring = " where DATE(tagCapturedTime) = '" + tagCapturedTime + "'";
				}
				if (req.body.daterange == "2") {
					wherestring = " where tagCapturedTime between date_sub(now(),INTERVAL 1 WEEK) and now()";
				}
				if (req.body.daterange == "3") {
					wherestring = " where tagCapturedTime between date_sub(now(),INTERVAL 2 WEEK) and now()";
				}
				if (req.body.daterange == "4") {
					wherestring = wherestring + " and tagCapturedTime < Now() and tagCapturedTime > DATE_ADD(Now(), INTERVAL- 1 MONTH)";
				}
				if (req.body.daterange == "5") {
					wherestring = wherestring + " and tagCapturedTime < Now() and tagCapturedTime > DATE_ADD(Now(), INTERVAL- 6 MONTH)";
				}
				if (req.body.daterange == "6") {
					wherestring = wherestring + " and tagCapturedTime < Now() and tagCapturedTime > DATE_ADD(Now(), INTERVAL- 12 MONTH)";
				}
			}else{
				if (req.body.sdate !== "0" && req.body.tagid !== "0") {

					let sdate = formatDate(new Date(req.body.sdate));
					wherestring = wherestring + " and DATE(tagCapturedTime) = '" + sdate + "'";

				}else{
					if (req.body.sdate !== "0") {

							let sdate = formatDate(new Date(req.body.sdate));
							wherestring = " where DATE(tagCapturedTime) = '" + sdate + "'";

					}
				}
			}
		}
		orderbystring = " STR_TO_DATE(tagCapturedTime, '%Y-%m-%d %H:%i:%s') "+ req.body.orderby;

		var sql = "select *, STR_TO_DATE(sd.gatewayReceivedTime, '%Y-%m-%d %H:%i:%s') as gatewayReceivedTime, STR_TO_DATE(sd.tagCapturedTime, '%Y-%m-%d %H:%i:%s') as tagCapturedTime, ROUND(sd.temperatureValue * 9.0 / 5.0 + 32, 2) as temperatureValue ";
		sql = sql + ", case when (select 1 from stationary s inner join gateways g on g.id = s.gatewayid where g.gatewayUUID=sd.gatewayId) = 1 ";
		sql = sql + " then (select stationaryname from stationary s inner join gateways g on g.id = s.gatewayid where g.gatewayUUID=sd.gatewayId)  WHEN (select 1 from moving m inner join gateways g on g.id = m.gatewayid where g.gatewayUUID=sd.gatewayId) = 1 then (select movingname from moving m inner join gateways g on g.id = m.gatewayid where g.gatewayUUID=sd.gatewayId)  else sd.gatewayId end as gatewayname ";
		sql = sql + ", case when (select 1 from stationary s inner join tags t on t.id = s.tagid where t.tagUUID=sd.tagId) = 1 ";
		sql = sql + " then (select stationaryname from stationary s inner join tags t on t.id = s.tagid where t.tagUUID=sd.tagId)  WHEN (select 1 from moving m inner join tags t on t.id = m.tagid where t.tagUUID=sd.tagId) = 1 then (select movingname from moving m inner join tags t on t.id = m.tagid where t.tagUUID=sd.tagId)  else sd.tagId end as tagname ";
		sql = sql + " from sensordata sd ";
		//sql = sql + " inner join gateways gw on gw.gatewayUUID = sd.gatewayid ";
		sql = sql + " inner join tags t on t.tagUUID = sd.tagid ";
		sql = sql + wherestring;
		sql = sql + " order by " + orderbystring;
		//console.log(sql);

		con.query(sql, function (err, result, fields) {
			if (err) throw err;
			//console.log(result);		
			res.json({ Result: result });
		});

	});

router.route('/GetMovingGatewayList')

	// create a bear (accessed at POST http://localhost:8080/api/GetMovingGatewayList)
	.get(function (req, res) {

		var sql = "select gatewayUUID, movingname from moving m"
		sql = sql + " inner join gateways g on g.id = m.gatewayid ";
		sql = sql + " order by m.id";
		con.query(sql, function (err, result, fields) {
			if (err) throw err;
			//console.log(result);		
			res.json({ Result: result });
		});

	});

router.route('/GetMovingTagList')

	// create a bear (accessed at POST http://localhost:8080/api/GetMovingTagList)
	.get(function (req, res) {

		var sql = "select tagUUID, movingname from moving m"
		sql = sql + " inner join tags g on g.id = m.tagid ";
		sql = sql + " order by m.id";
		con.query(sql, function (err, result, fields) {
			if (err) throw err;
			//console.log(result);		
			res.json({ Result: result });
		});

	});

router.route('/GetMovingMapSensorList')

	// create a bear (accessed at POST http://localhost:8080/api/GetMovingMapSensorList)
	.post(function (req, res) {

		var wherestring = "";
		var orderbystring = "";

		orderbystring = " STR_TO_DATE(timeOfPosition, '%Y-%m-%d %H:%i:%s') asc";

		if (req.body.mgatewayid !== "0") {
			wherestring = " where gw.gatewayUUID = '" + req.body.mgatewayid + "'";
		}
		if (req.body.mtagid !== "0") {
			wherestring = " where t.tagUUID = '" + req.body.mtagid + "'";
		}
		if (req.body.viewmode !== "0" && (req.body.mtagid !== "0" || req.body.mgatewayid !== "0")) {
			if (req.body.viewmode == "1") {
				orderbystring = " STR_TO_DATE(timeOfPosition, '%Y-%m-%d %H:%i:%s') desc LIMIT 1";
			}
			if (req.body.viewmode == "2") {
				// let timeOfPosition = formatDate(new Date());
				let timeOfPosition = formatDate(new Date(req.body.mdate));
				wherestring = wherestring + " and DATE(timeOfPosition) = '" + timeOfPosition + "'";
			}
		}
		var sql = "select *, STR_TO_DATE(sd.gatewayReceivedTime, '%Y-%m-%d %H:%i:%s') as gatewayReceivedTime, STR_TO_DATE(sd.tagCapturedTime, '%Y-%m-%d %H:%i:%s') as tagCapturedTime, STR_TO_DATE(sd.timeOfPosition, '%Y-%m-%d %H:%i:%s') as timeOfPosition, ROUND(sd.temperatureValue * 9.0 / 5.0 + 32, 2) as temperatureValue from sensordata sd ";
		sql = sql + " inner join gateways gw on gw.gatewayUUID = sd.gatewayid ";
		sql = sql + " inner join tags t on t.tagUUID = sd.tagid ";
		sql = sql + wherestring + " and sd.latitude <> '-200' ";
		sql = sql + " order by " + orderbystring;
		//console.log(sql);
		var dCRT = new Date(parseInt('1595496520100', 10));
		console.log(dCRT);
		con.query(sql, function (err, result, fields) {
			if (err) throw err;
			//console.log(result);		
			res.json({ Result: result });
		});

	});

router.route('/GetGatewayIdList')

	// create a bear (accessed at POST http://localhost:8080/api/GetGatewayIdList)
	.get(function (req, res) {

		var sql = "select g.id as gid, gatewayUUID, stationaryname as gname from stationary s"
		sql = sql + " inner join gateways g on g.id = s.gatewayid ";
		sql = sql + " union ";
		sql = sql + " select g.id as gid, gatewayUUID, movingname as gname from moving m ";
		sql = sql + " inner join gateways g on g.id = m.gatewayid ";
		con.query(sql, function (err, result, fields) {
			if (err) throw err;
			//console.log(result);		
			res.json({ Result: result });
		});

	});

router.route('/GetTagIdList')

	// create a bear (accessed at POST http://localhost:8080/api/GetMovingTagList)
	.get(function (req, res) {

		var sql = "select t.id as tid, tagUUID, stationaryname as tname from stationary s"
		sql = sql + " inner join tags t on t.id = s.tagid ";
		sql = sql + " union ";
		sql = sql + " select t.id as tid, tagUUID, movingname as tname from moving m ";
		sql = sql + " inner join tags t on t.id = m.tagid ";
		con.query(sql, function (err, result, fields) {
			if (err) throw err;
			//console.log(result);		
			res.json({ Result: result });
		});

	});

router.route('/GetMovingTagSensorList')

	// create a bear (accessed at POST http://localhost:8080/api/GetMovingTagSensorList)
	.post(function (req, res) {

		var wherestring = "";
		var orderbystring = "";

		orderbystring = " STR_TO_DATE(tagCapturedTime, '%Y-%m-%d %H:%i:%s') asc";

		if (req.body.mtagid !== "0") {
			wherestring = " where t.tagUUID = '" + req.body.mtagid + "'";
		}
		if (req.body.mdate !== "0" && req.body.mtagid !== "0") {

			let mdate = formatDate(new Date(req.body.mdate));
			wherestring = wherestring + " and DATE(tagCapturedTime) = '" + mdate + "'";
		}
		else {

			let mdate = formatDate(new Date(req.body.mdate));
			wherestring = " where DATE(tagCapturedTime) = '" + mdate + "'";

		}

		var sql = "select *, STR_TO_DATE(sd.gatewayReceivedTime, '%Y-%m-%d %H:%i:%s') as gatewayReceivedTime, STR_TO_DATE(sd.tagCapturedTime, '%Y-%m-%d %H:%i:%s') as tagCapturedTime, ROUND(sd.temperatureValue * 9.0 / 5.0 + 32, 2) as temperatureValue, case when (select 1 from stationary s inner join gateways g on g.id = s.gatewayid where g.gatewayUUID=sd.gatewayId) = 1 then (select stationaryname from stationary s inner join gateways g on g.id = s.gatewayid where g.gatewayUUID=sd.gatewayId)  WHEN (select 1 from moving m inner join gateways g on g.id = m.gatewayid where g.gatewayUUID=sd.gatewayId) = 1 then (select movingname from moving m inner join gateways g on g.id = m.gatewayid where g.gatewayUUID=sd.gatewayId)  else sd.gatewayId end as assetname from sensordata sd ";
		sql = sql + " inner join gateways g on g.gatewayUUID = sd.gatewayid ";
		sql = sql + " inner join tags t on t.tagUUID = sd.tagid ";
		sql = sql + wherestring;
		sql = sql + " order by " + orderbystring;
		//console.log(sql);

		con.query(sql, function (err, result, fields) {
			if (err) throw err;
			//console.log(result);		
			res.json({ Result: result });
		});

	});

router.route('/saveAlert')

	// create a bear (accessed at POST http://localhost:8080/api/saveAlert)
	.post(function (req, res) {
		let dateTime = formatDateTime(new Date());
		//console.log(dateTime);
		var sql = "insert into alerts (userid, gatewayid, tagid, variablename, upperlimit, lowerlimit, datecreated) values ( ";
		sql = sql + req.body.userid + "," + req.body.gatewayid + "," + req.body.tagid + ",'" + req.body.variablename + "','" + req.body.upperlimit + "','" + req.body.lowerlimit + "','" + dateTime + "')";
		con.query(sql, function (err, result, fields) {
			if (err) throw err;
			//console.log(result);		
			res.json({ Result: result });
		});
		//res.json({ Result: dateTime });
	});

router.route('/GetAlertSensorList')

	// create a bear (accessed at POST http://localhost:8080/api/GetAlertSensorList)
	.post(function (req, res) {

		get_alerts(function (resp) {

			var sql = "";
			var orderbystring = "";

			resp.forEach(al => {

				console.log(al["variablename"]);
				console.log(al["upperlimit"]);
				console.log(al["lowerlimit"]);

				var wherestring = "";
				var union = "";

				if(al["variablename"] == "Temperature" && al["upperlimit"] > 0 && al["lowerlimit"] == "undefined"){
					wherestring = wherestring + " where sd.temperaturevalue >= "+al["upperlimit"];
					if(sql !== ""){
						union = "union";
					}
					//console.log(wherestring);
				}
				if(al["variablename"] == "Temperature" && al["lowerlimit"] > 0 && al["upperlimit"] == "undefined"){
					wherestring = wherestring + " where sd.temperaturevalue <= "+al["lowerlimit"];
					if(sql !== ""){
						union = "union";
					}
				}

				if(al["variablename"] == "Humidity" && al["upperlimit"] > 0 && al["lowerlimit"] == "undefined"){
					wherestring = wherestring + " where sd.humidityvalue >= "+al["upperlimit"];
					if(sql !== ""){
						union = "union";
					}
				}
				if(al["variablename"] == "Humidity" && al["lowerlimit"] > 0 && al["upperlimit"] == "undefined"){
					wherestring = wherestring + " where sd.humidityvalue <= "+al["lowerlimit"];
					if(sql !== ""){
						union = "union";
					}
				}
				if(al["variablename"] == "Light" && al["upperlimit"] > 0 && al["lowerlimit"] == "undefined"){
					wherestring = wherestring + " where sd.lightvalue >= "+al["upperlimit"];
					if(sql !== ""){
						union = "union";
					}
				}
				if(al["variablename"] == "Light" && al["lowerlimit"] > 0 && al["upperlimit"] == "undefined"){
					wherestring = wherestring + " where sd.lightvalue <= "+al["lowerlimit"];
					if(sql !== ""){
						union = " union ";
					}
				}
				//console.log(wherestring);
				sql = sql + union;
				sql = sql + "select case when a.gatewayid <> 0 then (case when (select 1 from stationary s where s.gatewayid=a.gatewayid) = 1 then (select stationaryname from stationary s where s.gatewayid=a.gatewayid) WHEN (select 1 from moving m where m.gatewayid=a.gatewayid) = 1 then (select movingname from moving m where m.gatewayid=a.gatewayid) else g.gatewayUUID end) when a.tagid <> 0 then (case when (select 1 from stationary s where s.tagid=a.tagid) = 1 then (select stationaryname from stationary s where s.tagid=a.tagid) WHEN (select 1 from moving m where m.tagid=a.tagid) = 1 then (select movingname from moving m where m.tagid=a.tagid) else t.tagUUID end) end as assetname, a.datecreated as adatecreated, a.variablename";
				sql = sql + " , case when a.variablename = 'Temperature' then sd.temperaturevalue when a.variablename = 'Humidity' then sd.humidityvalue when a.variablename='Light' then sd.lightValue end as sensorvariablevalue";
				sql = sql + " , a.upperlimit, a.lowerlimit ";
				sql = sql + " , case when a.variablename = 'Temperature' and sd.temperaturevalue > a.upperlimit then 'red' when a.variablename = 'Humidity' and sd.humidityvalue > a.upperlimit then 'red'";
				sql = sql + " when a.variablename='Light' and sd.lightvalue > a.upperlimit then 'red' else '' end as redflag ";
				sql = sql + " from sensordata sd ";
				sql = sql + " inner join gateways g on g.gatewayUUID=sd.gatewayId ";
				sql = sql + " inner join tags t on t.tagUUID=sd.tagId ";
				sql = sql + " inner join alerts a on a.gatewayid = g.id or a.tagid = t.id ";
				sql = sql + wherestring;

				// var sql = "SELECT case when a.gatewayid <> 0 then (select gatewayUUID from gateways where id=a.gatewayid) when a.tagid <> 0 then (select tagUUID from tags where id=a.gatewayid) end as alertUUID ";
				// sql = sql + " from alerts a ";

				//console.log(sql);

				con.query(sql, function (err, result, fields) {
					if (err) throw err;
					//console.log(result);		
					res.json({ Result: result });
				});
			});
		});
	});

router.route('/GetAlertCreatedList')

	// create a bear (accessed at POST http://localhost:8080/api/GetAlertCreatedList)
	.post(function (req, res) {


		var wherestring = "";

		if (req.body.id > 0) {
			wherestring = " where a.id = " + req.body.id + "";
		}
		var sql = "select *, a.id as aid, a.datecreated as adatecreated ";
		sql = sql + ", case when (select 1 from stationary s inner join gateways g on g.id = s.gatewayid where g.id=a.gatewayId) = 1 ";
		sql = sql + " then (select stationaryname from stationary s inner join gateways g on g.id = s.gatewayid where g.id=a.gatewayId)  WHEN (select 1 from moving m inner join gateways g on g.id = m.gatewayid where g.id=a.gatewayid) = 1 then (select movingname from moving m inner join gateways g on g.id = m.gatewayid where g.id=a.gatewayId)  else g.gatewayUUID end as gatewayname";
		sql = sql + " , case when (select 1 from stationary s inner join tags t on t.id = s.tagid where t.id=a.tagId) = 1 ";
		sql = sql + " then (select stationaryname from stationary s inner join tags t on t.id = s.tagid where t.id=a.tagId)  WHEN (select 1 from moving m inner join tags t on t.id = m.tagid where t.id=a.tagId) = 1 then (select movingname from moving m inner join tags t on t.id = m.tagid where t.id=a.tagId)  else t.tagUUID end as tagname";
		sql = sql + " from alerts a";
		sql = sql + " left join gateways g on g.id = a.gatewayid ";
		sql = sql + " left join tags t on t.id = a.tagid ";
		sql = sql + wherestring;
		sql = sql + " order by a.id";
		//console.log(sql);
		con.query(sql, function (err, result, fields) {
			if (err) throw err;
			//console.log(result);		
			res.json({ Result: result });
		});

	});

	function get_alerts(callback) {
		
		var sql = "SELECT * FROM `alerts`";
		con.query(sql, function (err, result, fields) {
			if (err) throw err;
			callback(result);
		});
	
		
	}

router.route('/DeleteAlert')

	// create a bear (accessed at POST http://localhost:8080/api/DeleteAlert)
	.post(function (req, res) {

		var wherestring = "";

		if (req.body.id > 0) {
			wherestring = " where id = " + req.body.id + "";
		}
		var sql = "delete from alerts "
		sql = sql + wherestring;
		con.query(sql, function (err, result, fields) {
			if (err) throw err;
			//console.log(result);		
			res.json({ Result: result });
		});

	});

function formatDate(date) {
	var d = new Date(date),
		month = '' + (d.getMonth() + 1),
		day = '' + d.getDate(),
		year = d.getFullYear();

	if (month.length < 2)
		month = '0' + month;
	if (day.length < 2)
		day = '0' + day;

	return [year, month, day].join('-');
}

function formatDateTime(date) {
	var d = new Date(date),
		month = '' + (d.getMonth() + 1),
		day = '' + d.getDate(),
		year = d.getFullYear(),
		hour = d.getHours(),
		minute = d.getMinutes(),
		seconds = d.getSeconds();

	if (month.length < 2)
		month = '0' + month;
	if (day.length < 2)
		day = '0' + day;

	var datestring = [year, month, day].join('-');
	var timestring = [hour, minute, seconds].join(':');

	//return [year, month, day].join('-');
	return [datestring, timestring].join(' ');
}

// cron.schedule("* * * * *", function () {
// 	console.log("Running Cron Job");

// 	// get_shipments(function (resp) {
// 	// 	//console.log("shipments");
// 	// 	//console.log(resp);
// 	// 	const result = JSON.parse(resp);
// 	// 	//console.log("shipments");
// 	// 	result.shipments.forEach(s => {
// 	//s["id"]
// 	get_sensordata("412", function (resp) {

// 		//console.log(s["id"]);
// 		const result = JSON.parse(resp);
// 		//console.log("JSON.parse");
// 		result.sensordata.forEach(el => {
// 			//console.log(el.location["latitude"]);			
// 			var sql = "";

// 			var sql = "SELECT 1 FROM sensordata WHERE s_id = '" + el["_id"] + "' ORDER BY id LIMIT 1";
// 			con.query(sql, function (error, results, fields) {
// 				if (error) {
// 					CreateLog(error + "\r\n");
// 				}
// 				//console.log("sensordata length"+ results.length);
// 				var oldgatewayId = "";
// 				var oldtagId = "";

// 				//var date = '1475235770601';
// 				var dCRT = new Date(parseInt(el["cloudReceivedTime"], 10));
// 				var dGRT = new Date(parseInt(el["gatewayReceivedTime"], 10));
// 				var dTCT = new Date(parseInt(el["tagCapturedTime"], 10));
// 				var dTOP = new Date(parseInt(el.location["timeOfPosition"], 10));

// 				let cloudReceivedTime = formatDateTime(dCRT);
// 				let gatewayReceivedTime = formatDateTime(dGRT);
// 				let tagCapturedTime = formatDateTime(dTCT);
// 				let timeOfPosition = formatDateTime(dTOP);

// 				if (results.length > 0) {

// 					let dateTime = formatDateTime(new Date());
// 					var query = con.query(
// 						'Update sensordata ' +
// 						'SET cloudReceivedTime = ?, messageType = ?' +
// 						', packageId = ?, shipmentId = ?, referenceId = ?, lost = ?' +
// 						', pressureValue = ?, batteryAnomaly = ?, temperatureAnomaly = ?' +
// 						', humidityAnomaly = ?, shockAnomaly = ?, tiltAnomaly = ?' +
// 						', lightAnomaly = ?, pressureAnomaly = ?, gatewayReceivedTime = ?' +
// 						', tagCapturedTime = ?, tagId = ?, gatewayId = ?' +
// 						', lightValue = ?, humidityValue = ?, temperatureValue = ?' +
// 						', shockValue = ?, tiltValue = ?, batteryValue = ?, sd_v = ?' +
// 						', latitude = ?, longitude = ?, altitude = ?, positionUncertainty = ?' +
// 						', locationMethod = ?, timeOfPosition = ?, datecreated = ?' +
// 						' where s_id = ?',

// 						[cloudReceivedTime, el["messageType"], el["packageId"],
// 							el["shipmentId"], el["referenceId"], el["lost"], el["pressureValue"],
// 							el["batteryAnomaly"], el["temperatureAnomaly"], el["humidityAnomaly"], el["shockAnomaly"],
// 							el["tiltAnomaly"], el["lightAnomaly"], el["pressureAnomaly"], gatewayReceivedTime,
// 							tagCapturedTime, el["tagId"], el["gatewayId"], el["lightValue"],
// 							el["humidityValue"], el["temperatureValue"], el["shockValue"], el["tiltValue"],
// 							el["batteryValue"], el["__v"], el.location["latitude"], el.location["longitude"],
// 							el.location["altitude"], el.location["positionUncertainty"], el.location["locationMethod"],
// 							timeOfPosition, dateTime, el["_id"]
// 						]
// 					);
// 					if (error) {
// 						CreateLog(error + "\r\n");
// 					}

// 				} else {


// 					let dateTime = formatDateTime(new Date());
// 					var query = con.query(
// 						'INSERT INTO sensordata ' +
// 						'SET s_id = ?, cloudReceivedTime = ?, messageType = ?' +
// 						', packageId = ?, shipmentId = ?, referenceId = ?, lost = ?' +
// 						', pressureValue = ?, batteryAnomaly = ?, temperatureAnomaly = ?' +
// 						', humidityAnomaly = ?, shockAnomaly = ?, tiltAnomaly = ?' +
// 						', lightAnomaly = ?, pressureAnomaly = ?, gatewayReceivedTime = ?' +
// 						', tagCapturedTime = ?, tagId = ?, gatewayId = ?' +
// 						', lightValue = ?, humidityValue = ?, temperatureValue = ?' +
// 						', shockValue = ?, tiltValue = ?, batteryValue = ?, sd_v = ?' +
// 						', latitude = ?, longitude = ?, altitude = ?, positionUncertainty = ?' +
// 						', locationMethod = ?, timeOfPosition = ?, datecreated = ?',

// 						[el["_id"], cloudReceivedTime, el["messageType"], el["packageId"],
// 						el["shipmentId"], el["referenceId"], el["lost"], el["pressureValue"],
// 						el["batteryAnomaly"], el["temperatureAnomaly"], el["humidityAnomaly"], el["shockAnomaly"],
// 						el["tiltAnomaly"], el["lightAnomaly"], el["pressureAnomaly"], gatewayReceivedTime,
// 							tagCapturedTime, el["tagId"], el["gatewayId"], el["lightValue"],
// 						el["humidityValue"], el["temperatureValue"], el["shockValue"], el["tiltValue"],
// 						el["batteryValue"], el["__v"], el.location["latitude"], el.location["longitude"],
// 						el.location["altitude"], el.location["positionUncertainty"], el.location["locationMethod"],
// 							timeOfPosition, dateTime
// 						]
// 					);
// 					if (oldgatewayId !== el["gatewayId"]) {
// 						sync_GatewayIds(el["gatewayId"], 1);
// 						oldgatewayId = el["gatewayId"];
// 					}
// 					if (oldtagId !== el["tagId"]) {
// 						sync_TagIds(el["tagId"], 1);
// 						oldtagId = el["tagId"];
// 					}

// 					if (error) {
// 						CreateLog(error + "\r\n");
// 					}
// 				}

// 			});



// 		});
// 	});
// 	// 	});
// 	// });

// 	sync_RemoveDuplicateIds();

// });

var request = require('request');
function get_shipments(callback) {
	var options = {
		uri: 'http://iclpgva-ctval.australiaeast.cloudapp.azure.com:3001/shipments',
		method: 'GET',
		headers: { 'Content-Type': 'application/json', 'Authorization': 'OAuth 51iy6GjVSdp4FRuscrXbIUuoQ5v38ErumPGYJq7txhizTCbYLc9oUxrnZTQNQaqFAOtseXClq44MDhQsDJvXMA==' }
	};
	var res = '';
	request(options, function (error, response, body) {
		if (!error && response.statusCode == 200) {
			res = body;
		}
		else {
			res = 'Not Found';
		}
		callback(res);
	});
}

function sync_GatewayIds(gatewayid, userid) {
	var sql = "SELECT 1 FROM gateways WHERE gatewayUUID = '" + gatewayid + "' ORDER BY id LIMIT 1";
	con.query(sql, function (error, results, fields) {
		if (error) {
			CreateLog(error + "\r\n");
		}
		// console.log("gateways length");
		// console.log(results);
		if (results.length > 0) {

		} else {
			let dateTime = formatDateTime(new Date());
			var query = con.query(
				'INSERT INTO gateways ' +
				'SET gatewayUUID = ?, userid = ?, datecreated = ?',
				[gatewayid, userid, dateTime]
			);
			if (error) {
				CreateLog(error + "\r\n");
			}
		}
	});
}

function sync_TagIds(tagid, userid) {
	var sql = "SELECT 1 FROM tags WHERE tagUUID = '" + tagid + "' ORDER BY id LIMIT 1";
	con.query(sql, function (error, results, fields) {
		if (error) {
			CreateLog(error + "\r\n");
		}

		if (results.length > 0) {

		} else {
			let dateTime = formatDateTime(new Date());
			var query = con.query(
				'INSERT INTO tags ' +
				'SET tagUUID = ?, userid = ?, datecreated = ?',
				[tagid, userid, dateTime]
			);
			if (error) {
				CreateLog(error + "\r\n");
			}
		}
	});
}

function sync_RemoveDuplicateIds() {
	var queryGW = con.query(
		'DELETE t1 FROM  gateways t1' +
		' INNER JOIN  gateways t2' +
		' WHERE' +
		' t1.id < t2.id AND' +
		' t1.gatewayUUID = t2.gatewayUUID'
	);

	var queryTg = con.query(
		'DELETE t1 FROM tags t1' +
		' INNER JOIN tags t2' +
		' WHERE' +
		' t1.id < t2.id AND' +
		' t1.tagUUID = t2.tagUUID'
	);
}

function get_sensordata(shipment_id, callback) {
	var options = {
		uri: 'http://iclpgva-ctval.australiaeast.cloudapp.azure.com:3001/sensordata/' + shipment_id,
		method: 'GET',
		headers: { 'Content-Type': 'application/json', 'Authorization': 'OAuth 51iy6GjVSdp4FRuscrXbIUuoQ5v38ErumPGYJq7txhizTCbYLc9oUxrnZTQNQaqFAOtseXClq44MDhQsDJvXMA==' }
	};
	var res = '';
	request(options, function (error, response, body) {
		if (!error && response.statusCode == 200) {
			res = body;
		}
		else {
			res = 'Not Found';
		}
		callback(res);
	});
}

var fs = require('fs');
//E:/SARAVANAN_SOURCE/RattleTech/Projects/intelwarehouse-server/ErrorLog.log
function CreateLog(msg) {
	fs.appendFile("C:/intelwarehouse-server/ErrorLog.log", msg, function (err) {
		if (err) {
			return CreateLog(err);
		}
	});
}

// REGISTER OUR ROUTES -------------------------------
// all of our routes will be prefixed with /api
app.use('/api', router);
app.use(cors());

// START THE SERVER
// =============================================================================
app.listen(port);
console.log('Magic happens on port ' + port);