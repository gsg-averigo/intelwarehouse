// Importing required libraries 
const cron = require("node-cron");
const express = require("express");

app = express(); // Initializing app 
var mysql = require('mysql');

var con = mysql.createConnection({
	host: 'localhost',
	user: 'root',
	password: 'password',
	//password: '',
	database: 'intelwarehouse'
});

con.connect((err) => {
	if (err) throw err;
	console.log('Connected!');
});

// Creating a cron job which runs on every 10 minutes 
cron.schedule("*/1 * * * *", function () {
	console.log("running a task every 10 minutes");

	get_shipments(function (resp) {
		//console.log("shipments");
		//console.log(resp);
		//const result = JSON.parse(resp);
		// 	//console.log("shipments");
		// 	result.shipments.forEach(s => {
		//s["id"]
		resp.forEach(s => {
			// console.log(s["shipmentid"]);
			//return false;
			get_sensordata(s["shipmentid"], function (resp) {

				//console.log(s["id"]);
				const result = JSON.parse(resp);
				//console.log("JSON.parse");
				result.sensordata.forEach(el => {
					//console.log(el.location["latitude"]);			
					var sql = "";

					var sql = "SELECT 1 FROM sensordata WHERE s_id = '" + el["_id"] + "' ORDER BY id LIMIT 1";
					con.query(sql, function (error, results, fields) {
						if (error) {
							CreateLog(error + "\r\n");
						}
						//console.log("sensordata length"+ results.length);
						var oldgatewayId = "";
						var oldtagId = "";

						//var date = '1475235770601';
						var dCRT = new Date(parseInt(el["cloudReceivedTime"], 10));
						var dGRT = new Date(parseInt(el["gatewayReceivedTime"], 10));
						var dTCT = new Date(parseInt(el["tagCapturedTime"], 10));
						var dTOP = new Date(parseInt(el.location["timeOfPosition"], 10));

						let cloudReceivedTime = formatDateTime(dCRT);
						let gatewayReceivedTime = formatDateTime(dGRT);
						let tagCapturedTime = formatDateTime(dTCT);
						let timeOfPosition = formatDateTime(dTOP);

						if (results.length > 0) {

							let dateTime = formatDateTime(new Date());
							var query = con.query(
								'Update sensordata ' +
								'SET cloudReceivedTime = ?, messageType = ?' +
								', packageId = ?, shipmentId = ?, referenceId = ?, lost = ?' +
								', pressureValue = ?, batteryAnomaly = ?, temperatureAnomaly = ?' +
								', humidityAnomaly = ?, shockAnomaly = ?, tiltAnomaly = ?' +
								', lightAnomaly = ?, pressureAnomaly = ?, gatewayReceivedTime = ?' +
								', tagCapturedTime = ?, tagId = ?, gatewayId = ?' +
								', lightValue = ?, humidityValue = ?, temperatureValue = ?' +
								', shockValue = ?, tiltValue = ?, batteryValue = ?, sd_v = ?' +
								', latitude = ?, longitude = ?, altitude = ?, positionUncertainty = ?' +
								', locationMethod = ?, timeOfPosition = ?, datecreated = ?' +
								' where s_id = ?',

								[cloudReceivedTime, el["messageType"], el["packageId"],
									el["shipmentId"], el["referenceId"], el["lost"], el["pressureValue"],
									el["batteryAnomaly"], el["temperatureAnomaly"], el["humidityAnomaly"], el["shockAnomaly"],
									el["tiltAnomaly"], el["lightAnomaly"], el["pressureAnomaly"], gatewayReceivedTime,
									tagCapturedTime, el["tagId"], el["gatewayId"], el["lightValue"],
									el["humidityValue"], el["temperatureValue"], el["shockValue"], el["tiltValue"],
									el["batteryValue"], el["__v"], el.location["latitude"], el.location["longitude"],
									el.location["altitude"], el.location["positionUncertainty"], el.location["locationMethod"],
									timeOfPosition, dateTime, el["_id"]
								]
							);
							if (error) {
								CreateLog(error + "\r\n");
							}

						} else {


							let dateTime = formatDateTime(new Date());
							var query = con.query(
								'INSERT INTO sensordata ' +
								'SET s_id = ?, cloudReceivedTime = ?, messageType = ?' +
								', packageId = ?, shipmentId = ?, referenceId = ?, lost = ?' +
								', pressureValue = ?, batteryAnomaly = ?, temperatureAnomaly = ?' +
								', humidityAnomaly = ?, shockAnomaly = ?, tiltAnomaly = ?' +
								', lightAnomaly = ?, pressureAnomaly = ?, gatewayReceivedTime = ?' +
								', tagCapturedTime = ?, tagId = ?, gatewayId = ?' +
								', lightValue = ?, humidityValue = ?, temperatureValue = ?' +
								', shockValue = ?, tiltValue = ?, batteryValue = ?, sd_v = ?' +
								', latitude = ?, longitude = ?, altitude = ?, positionUncertainty = ?' +
								', locationMethod = ?, timeOfPosition = ?, datecreated = ?',

								[el["_id"], cloudReceivedTime, el["messageType"], el["packageId"],
								el["shipmentId"], el["referenceId"], el["lost"], el["pressureValue"],
								el["batteryAnomaly"], el["temperatureAnomaly"], el["humidityAnomaly"], el["shockAnomaly"],
								el["tiltAnomaly"], el["lightAnomaly"], el["pressureAnomaly"], gatewayReceivedTime,
									tagCapturedTime, el["tagId"], el["gatewayId"], el["lightValue"],
								el["humidityValue"], el["temperatureValue"], el["shockValue"], el["tiltValue"],
								el["batteryValue"], el["__v"], el.location["latitude"], el.location["longitude"],
								el.location["altitude"], el.location["positionUncertainty"], el.location["locationMethod"],
									timeOfPosition, dateTime
								]
							);
							if (oldgatewayId !== el["gatewayId"]) {
								sync_GatewayIds(el["gatewayId"], 1);
								oldgatewayId = el["gatewayId"];
							}
							if (oldtagId !== el["tagId"]) {
								sync_TagIds(el["tagId"], 1);
								oldtagId = el["tagId"];
							}

							if (error) {
								CreateLog(error + "\r\n");
							}
						}

					});



				});
			});
		});
	});

	sync_RemoveDuplicateIds();
});

var request = require('request');
function get_shipments(callback) {
	// var options = {
	// 	uri: 'http://iclpgva-ctval.australiaeast.cloudapp.azure.com:3001/shipments',
	// 	method: 'GET',
	// 	headers: { 'Content-Type': 'application/json', 'Authorization': 'OAuth 51iy6GjVSdp4FRuscrXbIUuoQ5v38ErumPGYJq7txhizTCbYLc9oUxrnZTQNQaqFAOtseXClq44MDhQsDJvXMA==' }
	// };
	// var res = '';
	// request(options, function (error, response, body) {
	// 	if (!error && response.statusCode == 200) {
	// 		res = body;
	// 	}
	// 	else {
	// 		res = 'Not Found';
	// 	}
	// 	callback(res);
	// });

	//var res = '';
	var sql = "SELECT * FROM `shipments`";
	con.query(sql, function (err, result, fields) {
		if (err) throw err;
		//console.log(result);		
		// res.json({ Result: result });
		//res = result;
		callback(result);
	});

	
}

function sync_GatewayIds(gatewayid, userid) {
	var sql = "SELECT 1 FROM gateways WHERE gatewayUUID = '" + gatewayid + "' ORDER BY id LIMIT 1";
	con.query(sql, function (error, results, fields) {
		if (error) {
			CreateLog(error + "\r\n");
		}
		// console.log("gateways length");
		// console.log(results);
		if (results.length > 0) {

		} else {
			let dateTime = formatDateTime(new Date());
			var query = con.query(
				'INSERT INTO gateways ' +
				'SET gatewayUUID = ?, userid = ?, datecreated = ?',
				[gatewayid, userid, dateTime]
			);
			if (error) {
				CreateLog(error + "\r\n");
			}
		}
	});
}

function sync_TagIds(tagid, userid) {
	var sql = "SELECT 1 FROM tags WHERE tagUUID = '" + tagid + "' ORDER BY id LIMIT 1";
	con.query(sql, function (error, results, fields) {
		if (error) {
			CreateLog(error + "\r\n");
		}

		if (results.length > 0) {

		} else {
			let dateTime = formatDateTime(new Date());
			var query = con.query(
				'INSERT INTO tags ' +
				'SET tagUUID = ?, userid = ?, datecreated = ?',
				[tagid, userid, dateTime]
			);
			if (error) {
				CreateLog(error + "\r\n");
			}
		}
	});
}

function sync_RemoveDuplicateIds() {
	var queryGW = con.query(
		'DELETE t1 FROM  gateways t1' +
		' INNER JOIN  gateways t2' +
		' WHERE' +
		' t1.id < t2.id AND' +
		' t1.gatewayUUID = t2.gatewayUUID'
	);

	var queryTg = con.query(
		'DELETE t1 FROM tags t1' +
		' INNER JOIN tags t2' +
		' WHERE' +
		' t1.id < t2.id AND' +
		' t1.tagUUID = t2.tagUUID'
	);
}

function get_sensordata(shipment_id, callback) {
	var options = {
		uri: 'https://ext-gva.ilogistics.info/sensordata/' + shipment_id,
		method: 'GET',
		headers: { 'Content-Type': 'application/json', 'Authorization': 'OAuth FDsUvYvvqet7P6XFT0hi+jje8Cp2TNjFnxXWF7KZsoW53h8jfTlZiKAynBUw3tw6M/OCZMzU2/6h21tqBIbVtg==' }
	};
	var res = '';
	request(options, function (error, response, body) {
		if (!error && response.statusCode == 200) {
			res = body;
		}
		else {
			res = 'Not Found';
		}
		callback(res);
	});
}

var fs = require('fs');
//E:/SARAVANAN_SOURCE/RattleTech/Projects/intelwarehouse-server/ErrorLog.log
function CreateLog(msg) {
	fs.appendFile("C:/intelwarehouse-server/ErrorLog.log", msg, function (err) {
		if (err) {
			return CreateLog(err);
		}
	});
}

function formatDate(date) {
	var d = new Date(date),
		month = '' + (d.getMonth() + 1),
		day = '' + d.getDate(),
		year = d.getFullYear();

	if (month.length < 2)
		month = '0' + month;
	if (day.length < 2)
		day = '0' + day;

	return [year, month, day].join('-');
}

function formatDateTime(date) {
	var d = new Date(date),
		month = '' + (d.getMonth() + 1),
		day = '' + d.getDate(),
		year = d.getFullYear(),
		hour = d.getHours(),
		minute = d.getMinutes(),
		seconds = d.getSeconds();

	if (month.length < 2)
		month = '0' + month;
	if (day.length < 2)
		day = '0' + day;

	var datestring = [year, month, day].join('-');
	var timestring = [hour, minute, seconds].join(':');

	//return [year, month, day].join('-');
	return [datestring, timestring].join(' ');
}

app.listen(3001);